package ClassesObjects;

public class Dog {

    private String name;
    public Dog(String name){
        this.name = name;
    }

    public void foo(Dog d){
        d.setName("Snoopy");
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }


}
