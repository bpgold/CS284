package ClassesObjects;

public class DogTest {
    public static void main(String[] args){
        Dog aDog = new Dog("Pluto");
        aDog.foo(aDog);
        System.out.println(aDog.getName());
    }
}
